// import React from "react";
// import { Modal, Button } from "react-bootstrap";
// // import LogoutModalImg from "./path_to_image"; // Replace with the actual path to your image

// function MyPlacesModal(props) {
//   return (
//     <Modal
//       {...props}
//       size="lg"
//       aria-labelledby="contained-modal-title-vcenter"
//       centered
//       backdrop="static"
//       style={{
//         zIndex: 2000, // Ensure modal appears on top
//       }}
//     >
//       <Modal.Body
//         style={{
//           backgroundColor: "#2A0181",
//           color: "white",
//           fontSize: "14px",
//           borderRadius: "10px",
//           padding: "30px",
//           position: "relative",
//         }}
//       >
//         <span
//           style={{
//             backgroundColor: "white",
//             color: "#2A0181",
//             fontSize: "20px",
//             position: "absolute",
//             right: "8px",
//             top: "10px",
//             width: "30px",
//             height: "30px",
//             textAlign: "center",
//             lineHeight: "30px",
//             fontWeight: "bolder",
//             borderRadius: "50%",
//             cursor: "pointer",
//           }}
//           onClick={props.onHide}
//         >
//           x
//         </span>

//         <h5 style={{ fontSize: "16px", paddingTop: "25px" }}>
//           Confirm Unfollowing
//         </h5>
//         <p style={{ fontSize: "14px", textAlign: "center" }}>
//           Unfollowing a company will delete all your Coupons from this company
//           and cancel all progress in coupons. You will stop receiving all future
//           offers from BASBAS. You can start following again once you tap their
//           Tagis tag in-store.
//         </p>
//         <Button
//           style={{
//             marginTop: "10px",
//             backgroundColor: "white",
//             color: "#2A0181",
//             fontWeight: "bold",
//             border: "white",
//             width: "100%",
//           }}
//           onClick={props.onHide}
//         >
//           Unfollow
//         </Button>
//       </Modal.Body>
//     </Modal>
//   );
// }

// export default MyPlacesModal;
